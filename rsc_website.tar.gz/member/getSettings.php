<?php 
echo "Settings here..";
?>